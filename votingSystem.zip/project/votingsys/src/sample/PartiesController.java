package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javax.swing.*;
import java.io.IOException;

public class PartiesController {


    @FXML
    private Image prosp;

    @FXML
    private ImageView prosperity;

    @FXML
    public void prosperityExited() {

        prosperity.setFitWidth(140.0);
        prosperity.setFitHeight(123.0);

    }

    @FXML
    public void prosperityEntered()
    {

        prosperity.setFitHeight(300.0);
        prosperity.setFitWidth(300.0);
        prosperity.setDisable(true);

        prosperity.setStyle("-fx-border-style:solid; -fx-border-width:5; -fx-border-color:red;");


    }

    public void balderasClicked() {


    }

    public void backButtonPressed() throws IOException {

        StartController.closeStage();

        StartController.loginWithBackOut();

    }
}
