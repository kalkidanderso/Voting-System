package sample;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class StartController {

    static Stage stage = new Stage();
    static Stage logOutStage = new Stage();
    static Stage registerStage = new Stage();
    @FXML
    private Button political;

    @FXML
    public void buttonEntered()
    {

        Tooltip tooltip = new Tooltip("Here you will get lists of political parties");
        tooltip.setStyle("fx-border-style:solid; -fx-border-width:4;");
        political.setTooltip(tooltip);
        political.setScaleX(2.0);
        political.setScaleY(2.0);

    }
    @FXML
    public void buttonExited()
    {
        political.setScaleX(1.0);
        political.setScaleY(1.0);

    }

    public static void closeStage()
    {
        stage.close();
    }

    @FXML
    public void buttonAction() throws Exception {

        Controller.closeStage();
        Controller.closeStartStage();
        stage.close();

        Stage stage1 = new Stage();
        BorderPane borderPane = new BorderPane();
        HBox hBox = new HBox();
        Button button = new Button("Back to Home");
        MenuBar menuBar = new MenuBar();


        menuBar.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                "   -fx-font-size:18;\n" +
                "    -fx-font-weight:Bold;");

        Menu file = new Menu("File");
        Menu Constitution = new Menu("Constitution");
        Menu Editor = new Menu("Editor");
        Menu Foxer = new Menu("Foxer");

        menuBar.getMenus().add(file);
        menuBar.getMenus().add(Constitution);
        menuBar.getMenus().add(Editor);
        menuBar.getMenus().add(Foxer);

        hBox.getChildren().add(menuBar);
        hBox.getChildren().add(button);

        borderPane.setTop(menuBar);
        List<String> list = new ArrayList<>();
        list.add("Prosperity");
        list.add("Balderas");
        list.add("Ezema");
        list.add("Ethiopian Democratic party");

        ObservableList<String> observableList = FXCollections.observableArrayList(list);

        ListView listView = new ListView();
        listView.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                "   -fx-font-size:18;\n" +
                "    -fx-font-weight:Bold;");



        listView.getItems().setAll(observableList);
        borderPane.setLeft(listView);
        String path = "C:\\Users\\KALE\\Documents\\NetBeansProjects\\BINGBANG - Copy\\src\\sample\\";
        String prospertiyS = "1.jpg";

        InputStream prosperityStream = new FileInputStream(path + prospertiyS);

        String balderasS = "2.jpg";

        InputStream balderasStream = new FileInputStream(path + balderasS);

        String ezemaS = "3.jpg";
        InputStream ezemaStream = new FileInputStream(path + ezemaS);

        String EDPS = "4.jpg";
        InputStream EDPStream = new FileInputStream(path + EDPS);

//        Image[] images = new Image[4];
        Image prosperity = new Image(prosperityStream);
        Image balderas = new Image(balderasStream);
        Image ezema = new Image(ezemaStream);
        Image edp = new Image(EDPStream);




        listView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observableValue, Object o, Object t1) {

                if (listView.getSelectionModel().getSelectedIndex() == 0){

                    ImageView imageView = new ImageView(prosperity);

                Thread  thread1 =     new Thread(new Runnable() {
                        @Override
                        public void run() {
                            for (int i = 0; i<361; i += 30){
                                try {
                                    Thread.sleep(100);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                imageView.setRotate(i);
                            }
                        }
                    });
                thread1.start();
                    VBox vBox = new VBox();
                    vBox.setAlignment(Pos.TOP_CENTER);
                    imageView.setFitWidth(170);
                    imageView.setFitHeight(170);

                    TextArea textArea = new TextArea();
                    textArea.setWrapText(true);
                    textArea.setEditable(false);
                    List<String> text = new ArrayList<>();
                    text.add("Party Name: Prosperity Party");
                    text.add("Prime Minister: PM. Dr Abiy Ahmmed");
                    text.add("is ruling know: true");
                    text.add("Our party is mostly important for economic growth of country");


                        new Thread(new Runnable() {
                            @Override
                            public void run() {

                                for (String string : text) {

                                    try {
                                        thread1.join();
                                        Thread.sleep(1000);

                                        textArea.appendText(string + '\n');

                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }).start();


                    textArea.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                            "   -fx-font-size:18;\n" +
                            "   -fx-background-color:black;\n" +
                            "    -fx-font-weight:Bold;");
                    vBox.getChildren().add(0, imageView);
                    vBox.getChildren().add(1, textArea);

                    borderPane.setCenter(vBox);

                }

                else if (listView.getSelectionModel().getSelectedIndex() == 1){

                    ImageView imageView = new ImageView(balderas);
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            for (int i = 0; i<361; i += 30){
                                try {
                                    Thread.sleep(100);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                imageView.setRotate(i);
                            }
                        }
                    }).start();
                    VBox vBox = new VBox();
                    vBox.setAlignment(Pos.TOP_CENTER);

                    imageView.setFitWidth(170);
                    imageView.setFitHeight(170);

                    imageView.setFitWidth(170);
                    imageView.setFitHeight(170);
                    vBox.getChildren().add(0, imageView);
                    borderPane.setCenter(vBox);



                }
                else if (listView.getSelectionModel().getSelectedIndex() == 2){

                    ImageView imageView = new ImageView(ezema);
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            for (int i = 0; i<361; i += 30){
                                try {
                                    Thread.sleep(100);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                imageView.setRotate(i);
                            }
                        }
                    }).start();
                    VBox vBox = new VBox();
                    vBox.setAlignment(Pos.TOP_CENTER);

                    imageView.setFitWidth(170);
                    imageView.setFitHeight(170);

                    vBox.getChildren().add(0, imageView);
                    borderPane.setCenter(vBox);

                }
                else if (listView.getSelectionModel().getSelectedIndex() == 3){

                    ImageView imageView = new ImageView(edp);
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            for (int i = 0; i<361; i += 30){
                                try {
                                    Thread.sleep(100);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                imageView.setRotate(i);
                            }
                        }
                    }).start();
                    VBox vBox = new VBox();
                    vBox.setAlignment(Pos.TOP_CENTER);

                    imageView.setFitWidth(170);
                    imageView.setFitHeight(170);
                    vBox.getChildren().add(0, imageView);
                    borderPane.setCenter(vBox);



                }


            }
        });


        button.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                "   -fx-font-size:18;\n" +
                "    -fx-font-weight:Bold;");

//        borderPane.setOpacity(1000000000);
//        borderPane.setCenter(vBox);

        listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        listView.getSelectionModel().selectFirst();

        Scene scene = new Scene(borderPane, 900, 700);
//        scene.getStylesheets().add(StartController.class.getResource("login.css").toExternalForm());
        stage1.setScene(scene);

        stage1.show();

         borderPane.setBottom(button);
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    stage1.close();
                    loginWithBackOut();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    public static void loginWithBackOut() throws IOException {

        Main.closeMainStage();

        Parent root = FXMLLoader.load(Controller.class.getResource("start.fxml"));
        stage.setTitle("Online Voting System");
        stage.setScene(new Scene(root, 1300, 700));
        stage.show();
    }

    public void AboutIsPressed(ActionEvent actionEvent) {

        Stage aboutStage = new Stage();
        stage.setTitle("About Project");
        BorderPane bPane = new BorderPane();
        stage.setScene(new Scene(bPane, 500, 400));
        stage.show();




    }

    public void logOutButtonIsPressed() throws Exception{

        Controller.closeStartStage();


        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        logOutStage.setTitle("Electronic Voting System");
        logOutStage.setScene(new Scene(root, 900, 500));
        logOutStage.show();
    }

    public static void closeLogOutStage(){
        logOutStage.close();
    }

    public void registerButtonPressed() {

        Controller.closeStartStage();
        GridPane gridPane = new GridPane();
        gridPane.setVgap(10);
        gridPane.setHgap(10);

        registerStage.setTitle("Electronic Voting System");
        registerStage.setScene(new Scene(gridPane, 900, 500));
        registerStage.show();


    }
}
