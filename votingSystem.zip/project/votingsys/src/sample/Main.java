package sample;

import database.AdminInfo;
import database.DatabaseController;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.NewStartController;
import model.RegisteringForBallot;

import javax.swing.*;
import java.awt.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class Main extends Application {

   private static TextField emailField = new TextField();
   private static PasswordField passwordField = new PasswordField();
   private static Button logInButton = new Button("Log In");

   private static String regExpForEmail = "^([a-zA-Z]+[\\@][a-zA-Z]+[\\.][a-zA-Z]+)$";
   private static String regExpForPassword = "^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#\\$%\\^&\\*]).{8,}$";

   static DatabaseController databaseController = new DatabaseController();
   static NewStartController newStartController = new NewStartController();

   Stage startStage = new Stage();


//    ^ the password start this way
//    must contain at least 1 lower case
//    must contain at least 1 upper case
//    must contain at least 1 numeric character
//    must contain at least 1 special character
//    must be eight character or longer

    private static Stage stage = new Stage();
    @Override
    public void start(Stage primaryStage) throws Exception {

               launchArgs();
    }



    public static void launchArgs() throws Exception{


//        RegisteringForBallot.mailTransfer("dersokalkidan@gmail.com", "kaleb.girma35@gmail.com");


        emailField.setText("");
        passwordField.setText("");

        //  Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));

        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setId("anchorPane");
        stage.setTitle("Electronic Voting System");
//         stage.setFullScreen(true)

        ///////////////////////////////////
        String path = "C:\\Users\\KALE\\Documents\\NetBeansProjects\\BINGBANG - Copy\\src\\sample\\";
        String voteImage = "vote.jpeg";

        InputStream voteStream = new FileInputStream(path + voteImage);


//        Image[] images = new Image[4];
        Image vote = new Image(voteStream);


        /////////////////////////////////////



        ImageView imageView = new ImageView(vote);
        imageView.setFitHeight(663.0);
        imageView.setFitWidth(1152.0);
        imageView.setLayoutX(-252.0);
        imageView.setLayoutY(-100.0);

        anchorPane.getChildren().add(imageView);

        Label logInLabel = new Label("Log in for Admin");
        logInLabel.setId("logInLabel");
        logInLabel.setLayoutX(264.0);
        logInLabel.setLayoutY(75.0);

        anchorPane.getChildren().add(logInLabel);

        Label emailLabel = new Label("Email");
        emailLabel.setId("emailLabel");
        emailLabel.setLayoutX(214.0);
        emailLabel.setLayoutY(216.0);

        anchorPane.getChildren().add(emailLabel);


        emailField.setId("emailFiel");
        emailField.setAlignment(Pos.CENTER);
        emailField.setLayoutX(283.0);
        emailField.setLayoutY(212.0);
        emailField.setOnKeyReleased(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {

                String email = emailField.getText().trim();
                String password = passwordField.getText().trim();

                boolean disableEmailButton = !(email.matches(regExpForEmail) &&  password.matches(regExpForPassword));

                logInButton.setDisable(disableEmailButton);

            }
        });


        emailField.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode().equals(KeyCode.ENTER)){
                    passwordField.requestFocus();
                }
            }
        });

        anchorPane.getChildren().add(emailField);



        Label passwordLabel = new Label("Password");
        passwordLabel.setId("passwordLabel");
        passwordLabel.setLayoutX(177.0);
        passwordLabel.setLayoutY(298.0);

        anchorPane.getChildren().add(passwordLabel);


        passwordField.setId("passwordFiled");
        passwordField.setAlignment(Pos.CENTER);
        passwordField.setLayoutX(283.0);
        passwordField.setLayoutY(294.0);

        passwordField.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode().equals(KeyCode.ENTER)){
                    if (!logInButton.isDisabled()) {
                        try {
                            logInButtonPressed();
                        } catch (Exception e) {
                            System.out.println("Something went wrong");
                        }
                    }


                }
            }
        });

        passwordField.setOnKeyReleased(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {

                String email = emailField.getText().trim();
                String password = passwordField.getText().trim();

                boolean disableEmailButton = !(email.matches(regExpForEmail) &&  password.matches(regExpForPassword));

                logInButton.setDisable(disableEmailButton);

            }
        });


        anchorPane.getChildren().add(passwordField);

        logInButton.setDisable(true);
        logInButton.setLayoutX(295.0);
        logInButton.setLayoutY(394.0);
        logInButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    logInButtonPressed();
                } catch (Exception e) {
                    System.out.println("Something went wrong");
                }
            }
        });

        anchorPane.getChildren().add(logInButton);



        Scene scene = new Scene(anchorPane, 900, 500);

        scene.getStylesheets().add(StartController.class.getResource("login.css").toExternalForm());

        stage.setScene(scene);
        stage.show();

    }

    public static void closeMainStage()
    {
        stage.close();
    }

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void init() throws Exception {
        super.init();
        DatabaseController.getInstance().openConnection();
    }

    @Override
    public void stop() throws Exception {
        super.stop();
        DatabaseController.getInstance().close();
    }
   public static void logInButtonPressed() throws Exception{

       List<AdminInfo> adminInfos = databaseController.getInstance().getAdminlogInfo();

       for (AdminInfo adminInfo : adminInfos) {
           String email = adminInfo.getEmail();
           String password = adminInfo.getPassword();
           boolean diffE = email.equals(emailField.getText());
           boolean diffP = password.equals(passwordField.getText());

           if (diffE && diffP) {

               Main.closeMainStage();
               Controller.closeStage();
               StartController.closeLogOutStage();

             newStartController.getInstance().start();


//               Parent root = FXMLLoader.load(Controller.class.getResource("start.fxml"));
//               startStage.setTitle("Online Voting System");
//               startStage.setScene(new Scene(root, 1300, 700));
//               startStage.show();


           } else {
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("regExp response");
               alert.setHeaderText("Wrong Email or password");
               alert.setContentText("Write the correct email address\n and password");
               alert.showAndWait();
               return;
           }
       }

   }

}










