package sample;

import database.AdminInfo;
import database.DatabaseController;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class Controller {

   static Stage stage = new Stage();

   static Stage startStage = new Stage();

    public TextField emailField;

    private DatabaseController databaseController = new DatabaseController();

    public PasswordField passwordField;
    public Button logInButton;

    @FXML
    private AnchorPane anchorPane;
    @FXML
    private Label logInLabel;

    private


    String regExpForEmail = "^([a-zA-Z]+[\\@][a-zA-Z]+[\\.][a-zA-Z]+)$";
    String regExpForPassword = "^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#\\$%\\^&\\*]).{8,}$";


//    ^ the password start this way
//    must contain at least 1 lower case
//    must contain at least 1 upper case
//    must contain at least 1 numeric character
//    must contain at least 1 special character
//    must be eight character or longer



    public void initialize() {
        logInButton.setDisable(true);
    }

    public void logInButtonPressed() throws Exception {

//        databaseController.getInstance().openConnection();
        List<AdminInfo> adminInfos = databaseController.getInstance().getAdminlogInfo();

        for (AdminInfo adminInfo : adminInfos) {
            String email = adminInfo.getEmail();
            String password = adminInfo.getPassword();
            boolean diffE = email.equals(emailField.getText());
            boolean diffP = password.equals(passwordField.getText());

            if (diffE && diffP) {

                Main.closeMainStage();
                Controller.closeStage();
                StartController.closeLogOutStage();

                Parent root = FXMLLoader.load(Controller.class.getResource("start.fxml"));
                startStage.setTitle("Online Voting System");
                startStage.setScene(new Scene(root, 1300, 700));
                startStage.show();


            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("regExp response");
                alert.setHeaderText("Wrong Email or password");
                alert.setContentText("Write the correct email address\n and password");
                alert.showAndWait();
                return;
            }
        }
    }


    public static void closeStage()
    {
        stage.close();
    }
    public static void closeStartStage()
    {
        startStage.close();
    }
    public void handleKeyReleased() {

        String email = emailField.getText().trim();
        String password = passwordField.getText().trim();

        boolean disableEmailButton = !(email.matches(regExpForEmail) &&  password.matches(regExpForPassword));

            logInButton.setDisable(disableEmailButton);


    }

    public void onKeyPressed(KeyEvent keyEvent) throws Exception{

    if (keyEvent.getCode().equals(KeyCode.ENTER)){
        if (!logInButton.isDisabled()) {
            logInButtonPressed();
        }


    }
    }
}











