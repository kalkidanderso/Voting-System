package model;

import database.DatabaseController;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.security.auth.Subject;
import java.sql.SQLException;
import java.util.Optional;
import java.util.Properties;

public class RegisteringForBallot {

   private static Label firstName = new Label("First Name: ");
    private static Label lastName = new Label("Last Name: ");
    private static  Label email = new Label("Email: ");
    private static Label id = new Label("ID: ");
    private static Label phone = new Label("Phone Number: ");

    private static TextField firstNameField = new TextField();
    private static TextField lastNameField = new TextField();
    private static TextField emailField = new TextField();
    private static TextField idField = new TextField();
    private static TextField phoneNumberField = new TextField();


    public static void registeringButtonPressed() throws SQLException {
        Dialog<ButtonType> dialog = new Dialog<>();
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        firstNameField.setMinWidth(500);
        lastNameField.setMinWidth(500);
        emailField.setMinWidth(500);
        idField.setMinWidth(500);
        phoneNumberField.setMinWidth(500);
        
        dialog.setHeight(500);
        dialog.setWidth(1000);
        gridPane.addRow(0, firstName, firstNameField);
        gridPane.addRow(1, lastName, lastNameField);
        gridPane.addRow(2, email, emailField);
        gridPane.addRow(3, id, idField);
        gridPane.addRow(4, phone, phoneNumberField);

        dialog.getDialogPane().setContent(gridPane);

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);



             Optional<ButtonType> result =  dialog.showAndWait();
             if (result.isPresent() && result.get().equals(ButtonType.OK)){
                   String firstname = firstNameField.getText().trim();
                   String lastname = lastNameField.getText().trim();
                   String email = emailField.getText().trim();
                   String id = idField.getText().trim();
                    String phone = phoneNumberField.getText().trim();

               boolean insert = DatabaseController.getInstance().insertVoterInformation(firstname, lastname, email, id, phone);

               if (insert == true){

                   new Thread(new Runnable() {
                       @Override
                       public void run() {

                           showAlert();
                       }
                   }).start();

               }

             }

    }




    public static void mailTransfer(String sender, String receiver){
        String host = "172.18.51.33";
        String to = receiver;
        String from = sender;
        Properties properties = System.getProperties();
        properties.setProperty("mail.smtp.host", host);
        Session session = Session.getDefaultInstance(properties);

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            message.setSubject("Ping");
            message.setText("Hello this is example of sending email");

            Transport.send(message);
            System.out.println("Message sent successfully....");
        } catch (AddressException e) {
            e.printStackTrace();
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    public static void showAlert(){

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText("Notifying that information is stored");
        alert.setContentText("You have successfully inserted data to the database");
        alert.showAndWait();
    }
}
