package model;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import sample.Main;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.EventListener;
import java.util.List;

public class NewStartController {


    private static NewStartController instance = new NewStartController();



    Stage startStage = new Stage();
    Stage stage1 = new Stage();

    String path = "C:\\Users\\KALE\\Documents\\NetBeansProjects\\BINGBANG - Copy\\src\\sample\\";
    Button political = new Button("Lists of Candidates");
     Button home = new Button("Home");
     Button about = new Button("About");
     Label label = new Label("E-Ballot");
     Button logOut = new Button("Log Out");
     
     Button registeringForTheBallot = new Button("Register for The ballot");


     public NewStartController getInstance()
     {
         return instance;
     }
    
    public void start() throws Exception{


        AnchorPane anchorPane = new AnchorPane();

        anchorPane.setPrefHeight(700.0);
         anchorPane.setPrefWidth(1300.0);

        String votingImage = "vote1.jpeg";
        InputStream votingStream = new FileInputStream(path + votingImage);


//        Image[] images = new Image[4];
        Image votes = new Image(votingStream);


        /////////////////////////////////////



        ImageView imageView = new ImageView(votes);
        imageView.setFitHeight(692.0);
        imageView.setFitWidth(1292.0);
        imageView.setLayoutX(8.0);
        imageView.setLayoutY(8.0);

        anchorPane.getChildren().add(imageView);

        political.setId("political");
        political.setLayoutX(654.0);
        political.setLayoutY(613.0);
        political.setPrefHeight(63.0);
        political.setPrefWidth(512.0);
        
        political.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                "   -fx-font-size:20;\n" +
                        "-fx-background-color:green;" +
                        "-fx-text-fill:white;" +
                "    -fx-font-weight:Bold;");

        political.setOnAction(e -> {
            try {
                politicalAction();
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
        });



        anchorPane.getChildren().add(political);


        home.setId("home");
        home.setLayoutX(1017.0);
        home.setLayoutY(145.0);
        home.setPrefWidth(123.0);
        home.setPrefHeight(74.0);
        
        home.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                "   -fx-font-size:20;\n" +
                "-fx-background-color:green;" +
                "-fx-text-fill:white;" +
                "    -fx-font-weight:Bold;");

        anchorPane.getChildren().add(home);


        about.setId("about");
        about.setLayoutX(1017.0);
        about.setLayoutY(290.0);
        about.setPrefHeight(63.0);
        about.setPrefWidth(127.0);
        about.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                "   -fx-font-size:20;\n" +
                "-fx-background-color:green;" +
                "-fx-text-fill:white;" +
                "    -fx-font-weight:Bold;");

        anchorPane.getChildren().add(about);

        about.setOnAction(e -> aboutButtonPressed());
        
        label.setAlignment(Pos.CENTER);
        label.setLayoutX(284.0);
        label.setLayoutY(23.0);

        label.setPrefHeight(63.0);
        label.setPrefWidth(551.0);
        label.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                "   -fx-font-size:30;\n" +
                "-fx-background-color:green;" +
                "-fx-text-fill:white;" +
                "    -fx-font-weight:Bold;");

        anchorPane.getChildren().add(label);


        logOut.setId("logOut");
        logOut.setLayoutX(986.0);
        logOut.setLayoutY(23.0);
        logOut.setPrefHeight(63.0);
        logOut.setPrefWidth(155.0);
        logOut.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                "   -fx-font-size:20;\n" +
                "-fx-background-color:green;" +
                "-fx-text-fill:white;" +
                "    -fx-font-weight:Bold;");


          logOut.setOnAction(e ->{
              try {
                  closeStartStage();
                  Main.launchArgs();

              } catch (Exception ex) {
                  ex.printStackTrace();
              }
          });

        anchorPane.getChildren().add(logOut);


        registeringForTheBallot.setId("registeringForTheBallot");
        registeringForTheBallot.setLayoutX(149.0);
        registeringForTheBallot.setLayoutY(619.0);
        registeringForTheBallot.setPrefHeight(63.0);
        registeringForTheBallot.setPrefWidth(403.0);

        registeringForTheBallot.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                "   -fx-font-size:20;\n" +
                "-fx-background-color:green;" +
                "-fx-text-fill:white;" +
                "    -fx-font-weight:Bold;");



        registeringForTheBallot.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                try {
                    RegisteringForBallot.registeringButtonPressed();
                } catch (SQLException e) {
                    System.out.println("Something went wrong during insertion");
                }
            }
        });

        anchorPane.getChildren().add(registeringForTheBallot);


        Button voter = new Button("Voter Information");

        voter.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                "   -fx-font-size:20;\n" +
                "-fx-background-color:green;" +
                "-fx-text-fill:white;" +
                "    -fx-font-weight:Bold;");

        voter.setLayoutX(987.0);
        voter.setLayoutY(465.0);
        voter.setPrefWidth(200.0);
        voter.setPrefHeight(74.0);

        voter.setOnAction(e -> {
            try {
                VoterInformationController.getResults();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });

        anchorPane.getChildren().add(voter);
        

        startStage.setTitle("Online Voting System");
        startStage.setScene(new Scene(anchorPane, 1300, 700));
        startStage.show();


    }

    public void closeStartStage(){
         startStage.close();
    }


    public void politicalAction() throws FileNotFoundException {
        startStage.close();





        BorderPane borderPane = new BorderPane();
        HBox hBox = new HBox();
        Button button = new Button("Back to Home");
        MenuBar menuBar = new MenuBar();




        menuBar.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                "   -fx-font-size:18;\n" +
                "    -fx-font-weight:Bold;");

        Menu file = new Menu("File");
        Menu Constitution = new Menu("Constitution");
        Menu Editor = new Menu("Editor");
        Menu Foxer = new Menu("Foxer");

        menuBar.getMenus().add(file);
        menuBar.getMenus().add(Constitution);
        menuBar.getMenus().add(Editor);
        menuBar.getMenus().add(Foxer);

        hBox.getChildren().add(menuBar);
        hBox.getChildren().add(button);

        borderPane.setTop(menuBar);
        List<String> list = new ArrayList<>();
        list.add("Angelina Devies");
        list.add("Marry Rows");
        list.add("Martin Odegard");
        list.add("Jovanci Locelso");

        ObservableList<String> observableList = FXCollections.observableArrayList(list);

        ListView listView = new ListView();
        listView.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                "   -fx-font-size:18;\n" +
                "    -fx-font-weight:Bold;");



        listView.getItems().setAll(observableList);
        borderPane.setLeft(listView);
//                String path = "C:\\Users\\KALE\\Documents\\NetBeansProjects\\BINGBANG - Copy\\src\\sample\\";
        String prospertiyS = "1.jpg";

        InputStream prosperityStream = null;
            prosperityStream = new FileInputStream(path + prospertiyS);

            String balderasS = "2.jpg";

            InputStream balderasStream = new FileInputStream(path + balderasS);
            String ezemaS = "3.jpg";
            InputStream ezemaStream = new FileInputStream(path + ezemaS);
            String EDPS = "4.jpg";
            InputStream EDPStream = new FileInputStream(path + EDPS);



//        Image[] images = new Image[4];
            Image prosperity = new Image(prosperityStream);
            Image balderas = new Image(balderasStream);
            Image ezema = new Image(ezemaStream);
            Image edp = new Image(EDPStream);



            listView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
                @Override
                public void changed(ObservableValue observableValue, Object o, Object t1) {

                    if (listView.getSelectionModel().getSelectedIndex() == 0){

                        ImageView imageView = new ImageView(prosperity);

                        Thread  thread1 =     new Thread(new Runnable() {
                            @Override
                            public void run() {
                                for (int i = 0; i<361; i += 30){
                                    try {
                                        Thread.sleep(100);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                    imageView.setRotate(i);
                                }
                            }
                        });
                        thread1.start();
                        VBox vBox = new VBox();
                        vBox.setAlignment(Pos.TOP_CENTER);
                        imageView.setFitWidth(170);
                        imageView.setFitHeight(170);

                        TextArea textArea = new TextArea();
                        textArea.setWrapText(true);
                        textArea.setEditable(false);
                        List<String> text = new ArrayList<>();
                        text.add("This is sample text");
                        text.add("This is sample text");
                        text.add("This is sample text");
                        text.add("This is sample text");


                        new Thread(new Runnable() {
                            @Override
                            public void run() {

                                for (String string : text) {

                                    try {
                                        thread1.join();
                                        Thread.sleep(1000);

                                        textArea.appendText(string + '\n');

                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }).start();


                        textArea.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                                "   -fx-font-size:18;\n" +
                                "   -fx-background-color:black;\n" +
                                "    -fx-font-weight:Bold;");
                        vBox.getChildren().add(0, imageView);
                        vBox.getChildren().add(1, textArea);

                        borderPane.setCenter(vBox);

                    }

                    else if (listView.getSelectionModel().getSelectedIndex() == 1){

                        ImageView imageView = new ImageView(balderas);
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                for (int i = 0; i<361; i += 30){
                                    try {
                                        Thread.sleep(100);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                    imageView.setRotate(i);
                                }
                            }
                        }).start();
                        VBox vBox = new VBox();
                        vBox.setAlignment(Pos.TOP_CENTER);

                        imageView.setFitWidth(170);
                        imageView.setFitHeight(170);

                        imageView.setFitWidth(170);
                        imageView.setFitHeight(170);
                        vBox.getChildren().add(0, imageView);
                        borderPane.setCenter(vBox);



                    }
                    else if (listView.getSelectionModel().getSelectedIndex() == 2){

                        ImageView imageView = new ImageView(ezema);
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                for (int i = 0; i<361; i += 30){
                                    try {
                                        Thread.sleep(100);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                    imageView.setRotate(i);
                                }
                            }
                        }).start();
                        VBox vBox = new VBox();
                        vBox.setAlignment(Pos.TOP_CENTER);

                        imageView.setFitWidth(170);
                        imageView.setFitHeight(170);

                        vBox.getChildren().add(0, imageView);
                        borderPane.setCenter(vBox);

                    }
                    else if (listView.getSelectionModel().getSelectedIndex() == 3){

                        ImageView imageView = new ImageView(edp);
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                for (int i = 0; i<361; i += 30){
                                    try {
                                        Thread.sleep(100);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                    imageView.setRotate(i);
                                }
                            }
                        }).start();
                        VBox vBox = new VBox();
                        vBox.setAlignment(Pos.TOP_CENTER);

                        imageView.setFitWidth(170);
                        imageView.setFitHeight(170);
                        vBox.getChildren().add(0, imageView);
                        borderPane.setCenter(vBox);



                    }


                }
            });


            button.setStyle("-fx-font-family:\"Times New Roman\", Times, Serif;\n" +
                    "   -fx-font-size:18;\n" +
                    "    -fx-font-weight:Bold;");

//        borderPane.setOpacity(1000000000);
//        borderPane.setCenter(vBox);


            listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            listView.getSelectionModel().selectFirst();


//        ProgressBar progressBar = new ProgressBar();
//        progressBar.setMinWidth(100);
//        progressBar.setVisible(false);
//
//        borderPane.setCenter(progressBar);
//
//        try{
//
//            progressBar.setVisible(true);
//            Thread.sleep(1000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        progressBar.setVisible(false);


            borderPane.setBottom(button);
            button.setOnAction(e -> {
                try {
                    backToHomeButton();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });




        Scene scene = new Scene(borderPane, 900, 700);
//        scene.getStylesheets().add(StartController.class.getResource("login.css").toExternalForm());
        stage1.setScene(scene);

        stage1.show();

    }


    public void politicalActionDemo() throws FileNotFoundException{

    }


    public void backToHomeButton() throws Exception{
         stage1.close();
         start();
    }

    public void aboutButtonPressed(){

        BorderPane pane = new BorderPane();
        VBox vBox = new VBox(5);
        TextArea textArea = new TextArea();
        textArea.appendText("The project is About Electronic voting System");
        textArea.appendText("\n The application is developed by the team, \n");
        textArea.appendText("Kalkidan Derso, \n");
        textArea.appendText("Kaleb Girma, \n");
        textArea.appendText("Leul Nigussie, \n");
        textArea.appendText("Leul Tsegaye, \n");
        textArea.appendText("Mohammed , \n");

        vBox.getChildren().add(textArea);


        pane.setCenter(vBox);

        Scene scene = new Scene(pane, 600, 400);
        Stage stage = new Stage();
        stage.setTitle("About The developers");
        stage.setScene(scene);

        stage.show();


    }
    }


