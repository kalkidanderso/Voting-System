package model;

import database.DatabaseController;
import database.VoterInfo;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import sample.StartController;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class VoterInformationController {


    private static Label firstName = new Label("First Name: ");
    private static Label lastName = new Label("Last Name: ");
    private static Label email = new Label("Email: ");
    private static Label id = new Label("ID: ");
    private static Label phone = new Label("Phone Number: ");
    private static Label password = new Label("Password: ");

    private static TextField firstNameField = new TextField();
    private static TextField lastNameField = new TextField();
    private static TextField emailField = new TextField();
    private static TextField idField = new TextField();
    private static TextField phoneNumberField = new TextField();
    private static PasswordField passwordField = new PasswordField();


    private static Stage stage = new Stage();
    private static BorderPane borderPane = new BorderPane();

  private static   Button updateButton = new Button("Update Voter Information");


    public static void getResults() throws SQLException {

        List<VoterInfo> voterInfos = DatabaseController.queryVoterInformation();
        stage.setTitle("Voter Information");
        TableView tableView = new TableView();

        TableColumn<String, VoterInfo> column1 = new TableColumn<>("First Name");
        column1.setCellValueFactory(new PropertyValueFactory<>("firstname"));


        TableColumn<String, VoterInfo> column2 = new TableColumn<>("Last Name");
        column2.setCellValueFactory(new PropertyValueFactory<>("lastname"));

        TableColumn<String, VoterInfo> column3 = new TableColumn<>("Email");
        column3.setCellValueFactory(new PropertyValueFactory<>("email"));

        TableColumn<String, VoterInfo> column4 = new TableColumn<>("Id");
        column4.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<String, VoterInfo> column5 = new TableColumn<>("Phone");
        column5.setCellValueFactory(new PropertyValueFactory<>("phone"));

        TableColumn<String, VoterInfo> column6 = new TableColumn<>("Password");
        column6.setCellValueFactory(new PropertyValueFactory<>("password"));

        tableView.getColumns().add(column1);
        tableView.getColumns().add(column2);
        tableView.getColumns().add(column3);
        tableView.getColumns().add(column4);
        tableView.getColumns().add(column5);
        tableView.getColumns().add(column6);

        for (VoterInfo voterInfo : voterInfos) {

            tableView.getItems().add(voterInfo);
        }

        borderPane.setCenter(tableView);
        borderPane.setBottom(updateButton);

        VoterInfo selectedItem = (VoterInfo) tableView.getSelectionModel().getSelectedItem();
        updateButton.setOnAction(e -> {
            System.out.println(selectedItem.getFirstname());
            try {
                updateInfo(selectedItem);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });

        Scene scene = new Scene(borderPane, 700, 555);

        scene.getStylesheets().add(VoterInformationController.class.getResource("voterIn.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }


    public static void updateInfo(VoterInfo voterInfo) throws SQLException {

//        if (voterInfo != null) {


//            public static void registeringButtonPressed() throws SQLException {
            Dialog<ButtonType> dialog = new Dialog<>();
            GridPane gridPane = new GridPane();
            gridPane.setHgap(10);
            gridPane.setVgap(10);

            firstNameField.setMinWidth(500);
            lastNameField.setMinWidth(500);
            emailField.setMinWidth(500);
            idField.setMinWidth(500);
            phoneNumberField.setMinWidth(500);
            passwordField.setMinWidth(500);

            dialog.setHeight(500);
            dialog.setWidth(1000);
            gridPane.addRow(0, firstName, firstNameField);
            gridPane.addRow(1, lastName, lastNameField);
            gridPane.addRow(2, email, emailField);
            gridPane.addRow(3, id, idField);
            gridPane.addRow(4, phone, phoneNumberField);
            gridPane.addRow(5, password, passwordField);

            dialog.getDialogPane().setContent(gridPane);

            dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
            dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

            firstNameField.setText(voterInfo.getFirstname());
            lastNameField.setText(voterInfo.getLastname());
            emailField.setText(voterInfo.getEmail());
            idField.setText(voterInfo.getId());
            phoneNumberField.setText(voterInfo.getPhone());
            passwordField.setText(voterInfo.getPassword());


            Optional<ButtonType> result = dialog.showAndWait();
            if (result.isPresent() && result.get().equals(ButtonType.OK)) {

                DatabaseController.deleteVoterInformation(voterInfo.getFirstname());

                String firstname = firstNameField.getText().trim();
                String lastname = lastNameField.getText().trim();

                String email = emailField.getText().trim();
                String id = idField.getText().trim();
                String phone = emailField.getText().trim();

                boolean insert = DatabaseController.getInstance().insertVoterInformation(firstname, lastname, email, id, phone);


//         else {
//            Alert alert = new Alert(Alert.AlertType.ERROR);
//            alert.setTitle("notification");
//            alert.setHeaderText("No item is selected");
//            alert.setContentText("Select an item to update");
//            alert.showAndWait();
//
//
//        }

            }
    }
}