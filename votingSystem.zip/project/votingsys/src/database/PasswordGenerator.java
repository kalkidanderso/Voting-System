package database;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class PasswordGenerator {

    // SecureRandom() constructs a secure random number generator (RNG) implementing the default random number algorithm.
    private final SecureRandom crunchifyRandomNo = new SecureRandom();

    private final List<Character> crunchifyValueObj;

    // Just initialize ArrayList crunchifyValueObj and add ASCII Decimal Values

    private static String passwd = "";

    public PasswordGenerator() {

        crunchifyValueObj = new ArrayList<>();

        // Adding ASCII Decimal value between 33 and 53
        for (int i = 33; i < 53; i++) {
            crunchifyValueObj.add((char) i);
        }

        // Adding ASCII Decimal value between 54 and 85
        for (int i = 54; i < 85; i++) {
            crunchifyValueObj.add((char) i);
        }

        // Adding ASCII Decimal value between 86 and 128
        for (int i = 86; i < 127; i++) {
            crunchifyValueObj.add((char) i);
        }

        // crunchifyValueObj.add((char) 64);

        // rotate() rotates the elements in the specified list by the specified distance. This will create strong password
        // Totally optional
        Collections.rotate(crunchifyValueObj, 5);
    }

    public static String main() {

        PasswordGenerator passwordGenerator = new PasswordGenerator();

        StringBuilder crunchifyBuilder = new StringBuilder();

        // Let's print total 8 passwords

            // Password length should be 23 characters
            for (int length = 0; length < 8; length++) {
                crunchifyBuilder.append(passwordGenerator.crunchifyGetRandom());
            }
            String crunch = crunchifyBuilder.toString();

            crunchifyBuilder.setLength(0);
        return crunch;

    }


    // Get Char value from above added Decimal values
    // Enable Logging below if you want to debug
    public char crunchifyGetRandom() {

        char crunchifyChar = this.crunchifyValueObj.get(crunchifyRandomNo.nextInt
                (this.crunchifyValueObj.size()));

        // log(String.valueOf(crunchifyChar));
        return crunchifyChar;
    }

}






