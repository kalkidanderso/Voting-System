package database;

import javafx.beans.property.SimpleStringProperty;

public class AdminInfo {

    private SimpleStringProperty email;
    private SimpleStringProperty password;


    public AdminInfo(){
        email = new SimpleStringProperty("");
        password = new SimpleStringProperty("");
    }

    public String getEmail() {
        return email.get();
    }

    public String emailProperty() {
        return email.get();
    }

    public void setEmail(String email) {
        this.email.set(email);
    }

    public String getPassword() {
        return password.get();
    }

    public String passwordProperty() {
        return password.get();
    }

    public void setPassword(String password) {
        this.password.set(password);
    }
}
