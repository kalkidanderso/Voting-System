package database;

import javafx.beans.property.SimpleStringProperty;

public class VoterInfo {


    private SimpleStringProperty firstname;
    private SimpleStringProperty lastname;
    private SimpleStringProperty email;
    private SimpleStringProperty id;
    private SimpleStringProperty phone;
    private SimpleStringProperty password;


    public VoterInfo(){
        firstname = new SimpleStringProperty("");
        lastname = new SimpleStringProperty("");
        email = new SimpleStringProperty("");
        id = new SimpleStringProperty("");
        phone = new SimpleStringProperty("");
        password = new SimpleStringProperty("");
    }

    public String getFirstname() {
        return firstname.get();
    }


    public void setFirstname(String firstname) {
        this.firstname.set(firstname);
    }

    public String getLastname() {
        return lastname.get();
    }


    public void setLastname(String lastname) {
        this.lastname.set(lastname);
    }

    public String getId() {
        return id.get();
    }


    public void setId(String id) {
        this.id.set(id);
    }

    public String getPhone() {
        return phone.get();
    }



    public void setPhone(String phone) {
        this.phone.set(phone);
    }

    public String getEmail() {
        return email.get();
    }


    public void setEmail(String email) {
        this.email.set(email);
    }

    public String getPassword() {
        return password.get();
    }


    public void setPassword(String password) {
        this.password.set(password);
    }


}
