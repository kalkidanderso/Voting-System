package database;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseController {

    private static DatabaseController instance = new DatabaseController();

    public static final String CONNECTION_STRING = "jdbc:mysql://localhost:3306/votingSystem";

    public static final String TABLE_ADMIN_LOGIN = "admin_login";
    public static final String COLUMN_ADMIN_EMAIL = "email";
    public static final String COLUMN_ADMIN_PASSWORD = "password";
    public static final String userName = "root";
    public static final String password = "kalkidan@123";

    public static final String QUERY_ADMIN_INFO = "SELECT * FROM " + TABLE_ADMIN_LOGIN;

    public static final String TABLE_VOTER_INFORMATION = "voter_information";
    public static final String COLUMN_FIRST_NAME = "firstname";
    public static final String COLUMN_LAST_NAME = "lastname";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_PHONE = "phone";
    public static final String COLUMN_PASSWORD = "password";

    public static final String CREATING_TABLE_VOTER_INFO = "CREATE TABLE IF NOT EXISTS "
            + TABLE_VOTER_INFORMATION + '(' + COLUMN_FIRST_NAME + " varchar(40)" + ", "
            + COLUMN_LAST_NAME + " varchar(40)" + ", "
            + COLUMN_EMAIL + " varchar(40)" + ", " + COLUMN_ID + " varchar(40)" + ", " + COLUMN_PHONE + " varchar(40)"
            + ", " + COLUMN_PASSWORD + " varchar(30)" + ")";


    public static final String INSERT_INTO_VOTER_INFORMATION = "INSERT INTO " + TABLE_VOTER_INFORMATION
            + "(" + COLUMN_FIRST_NAME + ", " + COLUMN_LAST_NAME + ", " + COLUMN_EMAIL
            + ", " + COLUMN_ID + ", " + COLUMN_PHONE + ", " + COLUMN_PASSWORD + ") VALUES (?, ?, ?, ?, ?, ?)";



    public static final String QUERY_VOTER_INFO = "SELECT * FROM " + TABLE_VOTER_INFORMATION;
    public static final String DELETE_VOTER_INFO = "DELETE FROM " + TABLE_VOTER_INFORMATION + " WHERE " + COLUMN_FIRST_NAME + " = ?";

    private PreparedStatement adminPrepStatment;
    private Connection connection;
    private PreparedStatement voterPrePStat;
    private static PreparedStatement deleteVoterPrep;

    private PreparedStatement insertIntoVoterInformation;

    private static PreparedStatement queryVoterInfoPrepared;

    public static DatabaseController getInstance(){
        return instance;
    }

    public void openConnection(){

        try {
            connection = DriverManager.getConnection(CONNECTION_STRING, userName, password);
            adminPrepStatment = connection.prepareStatement(QUERY_ADMIN_INFO);
            voterPrePStat = connection.prepareStatement(CREATING_TABLE_VOTER_INFO);
            insertIntoVoterInformation = connection.prepareStatement(INSERT_INTO_VOTER_INFORMATION);
            queryVoterInfoPrepared = connection.prepareStatement(QUERY_VOTER_INFO);
            deleteVoterPrep = connection.prepareStatement(DELETE_VOTER_INFO);


            System.out.println("Connection opened successfully");
        }catch (SQLException e){
            System.out.println("Something went wrong with database opening: " + e.getMessage());
        }

    }

    public void close(){
        try {
            if (connection != null) {
                connection.close();
            }
            if (adminPrepStatment != null){
                adminPrepStatment.close();
            }

            if (voterPrePStat != null){
                voterPrePStat.close();
            }
            if (insertIntoVoterInformation != null){
                insertIntoVoterInformation.close();
            }

            if (queryVoterInfoPrepared != null){
                queryVoterInfoPrepared.close();
            }
            if (deleteVoterPrep != null){
                deleteVoterPrep.close();
            }

        }catch (SQLException e){
            System.out.println("Couldn't close the database: " + e.getMessage());
        }
    }

    public List<AdminInfo> getAdminlogInfo() throws SQLException{

        List<AdminInfo> adminInfos = new ArrayList<>();

        ResultSet result = adminPrepStatment.executeQuery();
        while (result.next()){
            AdminInfo adminInfo = new AdminInfo();
            adminInfo.setEmail(result.getString(1));
            adminInfo.setPassword(result.getString(2));
            adminInfos.add(adminInfo);
        }

        return adminInfos;

    }

    public void createVoterInfoTable() throws Exception{
        voterPrePStat.execute();
    }

    public boolean insertVoterInformation(String firstName, String lastName, String email, String id, String phone) throws SQLException{

        insertIntoVoterInformation.setString(1, firstName);
        insertIntoVoterInformation.setString(2, lastName);
        insertIntoVoterInformation.setString(3, email);
        insertIntoVoterInformation.setString(4, id);
        insertIntoVoterInformation.setString(5, phone);


        String randomPassword = PasswordGenerator.main();

        insertIntoVoterInformation.setString(6, randomPassword);

      boolean inserted =   insertIntoVoterInformation.execute();

           return inserted;


    }

    public static List<VoterInfo> queryVoterInformation() throws SQLException{

        ResultSet resultSet = queryVoterInfoPrepared.executeQuery();
        List<VoterInfo> voterInfos = new ArrayList<>();

        while (resultSet.next()){
            VoterInfo voterInfo = new VoterInfo();
           voterInfo.setFirstname(resultSet.getString(1));
           voterInfo.setLastname(resultSet.getString(2));
           voterInfo.setEmail(resultSet.getString(3));
           voterInfo.setId(resultSet.getString(4));
           voterInfo.setPhone(resultSet.getString(5));
           voterInfo.setPassword(resultSet.getString(6));

           voterInfos.add(voterInfo);
            System.out.println(voterInfo.getFirstname() + " " +voterInfo.getLastname() + " "
                    + voterInfo.getEmail() + " " + voterInfo.getId() + " "
                    + voterInfo.getPhone() + " " + voterInfo.getPassword());
        }

        return voterInfos;
    }

    public static void deleteVoterInformation(String firstname) throws SQLException{
        deleteVoterPrep.setString(1, firstname);

        deleteVoterPrep.executeQuery();
    }

}
